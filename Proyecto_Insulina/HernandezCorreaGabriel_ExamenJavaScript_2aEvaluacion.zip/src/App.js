import React from 'react';
import Formula1Main from './pages/Formula1Main';

function App() {
    return (
        <div>
            <Formula1Main />
        </div>
    );
}

export default App;
